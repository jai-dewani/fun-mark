from .Benchmark import Benchmark as bm
__all__ = ["Benchmark"]
Benchmark = bm