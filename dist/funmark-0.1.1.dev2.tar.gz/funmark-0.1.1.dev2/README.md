# FunMark

A package to bench-mark python fun-ctions

